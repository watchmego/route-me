
import ('./header.css');

export default function HeaderBox() {
    return (
        <div className="header">
            <div>logo</div>
            <div>route me</div>
            <div>login/signup</div>
        </div>
    )
}