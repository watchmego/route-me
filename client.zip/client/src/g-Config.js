export const globalConfig = {
    API_KEY: 'OPCQtjyuB3pOY2EpHh5u',
    GH_API:  '3232ea12-5d11-4c46-a8ca-b32cf41700ca'
};